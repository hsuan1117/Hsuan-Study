//
//  TodayViewController.swift
//  today
//
//  Created by 張睿玹 on 2020/1/7.
//  Copyright © 2020 hsuan. All rights reserved.
//

import UIKit
import NotificationCenter

class TodayViewController: UIViewController, NCWidgetProviding {
        
    @IBOutlet weak var BtnTNFSH: UIButton!
    override func viewDidAppear(_ animated: Bool) {
        BtnTNFSH.layer.cornerRadius = 10
        BtnTNFSH.layer.borderWidth = 0.5
        BtnTNFSH.layer.borderColor = UIColor.black.cgColor
        self.extensionContext?.widgetLargestAvailableDisplayMode = .expanded
    }
    @IBAction func BtnGoTNFSH(_ sender: Any) {
        let url = URL(string: "hs://TNFSH")!
        self.extensionContext?.open(url, completionHandler: nil)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
        
    func widgetPerformUpdate(completionHandler: (@escaping (NCUpdateResult) -> Void)) {
        // Perform any setup necessary in order to update the view.
        
        // If an error is encountered, use NCUpdateResult.Failed
        // If there's no update required, use NCUpdateResult.NoData
        // If there's an update, use NCUpdateResult.NewData
        
        completionHandler(NCUpdateResult.newData)
    }
    
}
