//
//  Account.swift
//  Hsuan Study
//
//  Created by student on 2019/12/20.
//  Copyright © 2019 tnfsh. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON
class Account: UIViewController {
    @IBOutlet weak var GifLoading: UIImageView!
    @IBOutlet weak var Account_Input: UITextField!
    @IBOutlet weak var Password_Input: UITextField!
    @IBOutlet weak var Label_AccountStatus: UILabel!
    @IBAction func Login(_ sender: Any) {
        let url = "https://script.google.com/macros/s/AKfycby-p_wJnMlqJ9cMp6z9s31PzCFGD8JB5kT3QBrdik-biF6VQpDI/exec?method=Login&account=\(Account_Input.text!)&password=\(Password_Input.text!)"
        GifLoading.isHidden = false
        
        AF.request(url,method: .get).validate().responseJSON { response in
            if let json = try? JSON(data:response.data!) {
                if json["status"].intValue == 1 {
                    self.GifLoading.isHidden = true
                    let alertController = UIAlertController(title: "Account Status", message: "Login Done", preferredStyle: .alert)
                    alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                    self.present(alertController, animated: true, completion: nil)
                    UserDefaults.standard.set(json["session_id"].stringValue, forKey:"AccessToken")
                    self.viewDidLoad()
                }
            }
        }
    }
    @IBAction func Logout(_ sender: Any) {
        UserDefaults.standard.set(nil, forKey:"AccessToken")
        self.viewDidLoad()
    }
    @IBAction func Register(_ sender: Any) {
        let url = "https://script.google.com/macros/s/AKfycby-p_wJnMlqJ9cMp6z9s31PzCFGD8JB5kT3QBrdik-biF6VQpDI/exec?method=Register&account=\(Account_Input.text!)&password=\(Password_Input.text!)"
        
        GifLoading.isHidden = false
        AF.request(url,method: .get).validate().responseJSON { response in
            print(response)
            if let json = try? JSON(data:response.data!) {
                print(response)
                if json["status"].intValue == 1 {
                    self.GifLoading.isHidden = true
                    let alertController = UIAlertController(title: "Account Status", message: "Register Done, Please Login", preferredStyle: .alert)
                    alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                    self.present(alertController, animated: true, completion: nil)
                    self.viewDidLoad()
                }else{
                    self.GifLoading.isHidden = true
                    let alertController = UIAlertController(title: "Account Status", message: "Register Fail, \(json["error"].stringValue)", preferredStyle: .alert)
                    alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                    self.present(alertController, animated: true, completion: nil)
                    self.viewDidLoad()
                }
            }
        }
    }
    @IBOutlet weak var btn_Login: UIButton!
    @IBOutlet weak var btn_Register: UIButton!
    @IBOutlet weak var btn_Panel: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.hideKeyboardWhenTappedAround()
        // 設定漸層顏色
        let color1 =  #colorLiteral(red: 0.2392156869, green: 0.6745098233, blue: 0.9686274529, alpha: 1).cgColor
        let color2 =  #colorLiteral(red: 0.721568644, green: 0.8862745166, blue: 0.5921568871, alpha: 1).cgColor
        let gradientLayer = CAGradientLayer()
        gradientLayer.frame = view.frame
        // color1 為第一個漸層色，color2 為第二個漸層色。
        gradientLayer.colors = [color1,color2]
        
        view.layer.insertSublayer(gradientLayer, at: 0)
        //先載入
        GifLoading.isHidden = true
        GifLoading.loadGif(name: "loading")
        self.view.bringSubviewToFront(GifLoading)
        
        if let AccessToken = UserDefaults.standard.object(forKey: "AccessToken") as? String {
            Label_AccountStatus.text = "Logined In"
            Label_AccountStatus.textColor = UIColor.blue
            btn_Login.isHidden = true
            btn_Register.isHidden = true
            btn_Panel.isHidden = false
            Account_Input.isHidden = true
            Password_Input.isHidden = true
        }else{
            Label_AccountStatus.text = "Not Logined In"
            Label_AccountStatus.textColor = UIColor.red
            btn_Login.isHidden = false
            btn_Register.isHidden = false
            btn_Panel.isHidden = true
            Account_Input.isHidden = false
            Password_Input.isHidden  = false
        }
    }
}
