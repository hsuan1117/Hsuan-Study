//
//  StudyTool.swift
//  Hsuan Study
//
//  Created by student on 2019/12/25.
//  Copyright © 2019 tnfsh. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON
import AVFoundation
class StudyTool: UIViewController,UIPickerViewDelegate,UIPickerViewDataSource {
    
    let allLanguage = ["en-US","zh-TW"]
    let UIallLanguage = ["英文","繁體中文"]
    var selectedLang:Int = 0
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return allLanguage.count
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        selectedLang = row
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return UIallLanguage[row]
    }
    @IBOutlet weak var label_LuckyNumber: UITextView!
    @IBOutlet weak var GifLoading: UIImageView!
    @IBOutlet weak var pv_Language: UIPickerView!
    @IBOutlet weak var label_Word: UILabel!
    @IBOutlet weak var label_WordMeaning: UILabel!
    @IBOutlet weak var input_ReadOut: UITextField!
    @IBAction func btn_ReadOutClicked(_ sender: Any) {
        let string = input_ReadOut.text!
        let utt = AVSpeechUtterance(string: string)
        utt.voice = AVSpeechSynthesisVoice(language: "en-US")
        AVSpeechSynthesizer().speak(utt)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.hideKeyboardWhenTappedAround()
        // 設定漸層顏色
        let color1 =  #colorLiteral(red: 0.8039215803, green: 0.8039215803, blue: 0.8039215803, alpha: 1).cgColor
        let color2 =  #colorLiteral(red: 0.9568627477, green: 0.6588235497, blue: 0.5450980663, alpha: 1).cgColor
        let gradientLayer = CAGradientLayer()
        gradientLayer.frame = view.frame
        // color1 為第一個漸層色，color2 為第二個漸層色。
        gradientLayer.colors = [color1,color2]
        
        view.layer.insertSublayer(gradientLayer, at: 0)
        //先載入
        GifLoading.isHidden = true
        GifLoading.loadGif(name: "loading2")
        
        pv_Language.delegate = self
        pv_Language.dataSource = self
        label_LuckyNumber.text = "幸運數字\n（說不定是分數XD : \(Int.random(in: 1...100))"
        let url = "https://script.google.com/macros/s/AKfycby-p_wJnMlqJ9cMp6z9s31PzCFGD8JB5kT3QBrdik-biF6VQpDI/exec?method=getWord"
        GifLoading.isHidden = false
        AF.request(url,method: .get).validate().responseJSON { response in
            self.GifLoading.isHidden = true
            if let json = try? JSON(data:response.data!) {
                //print(json["word"].stringValue)
               
                self.label_Word.text = json["word"].stringValue
                
                self.label_WordMeaning.text = json["meaning"].stringValue
            }
            
        }
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
