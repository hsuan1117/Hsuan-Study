//
//  Game.swift
//  Hsuan Study
//
//  Created by 張睿玹 on 2020/1/8.
//  Copyright © 2020 hsuan. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation
class Game: UIViewController {
    var locationManager = CLLocationManager()
    @IBOutlet weak var Map: MKMapView!
    @IBOutlet weak var SlideObject: UISlider!
    @IBOutlet weak var SlideValue: UILabel!
    
    @IBAction func MakeShuffle(_ sender: Any) {
        
        let value = Int(SlideObject.value)
        /**
         * #建立一個陣列存放要抽籤的項目
         */
        var toShuffle : Array<Int> = []
        for i in 1...value {
            toShuffle.append(i)
        }
        toShuffle.shuffle()
        let alertController = UIAlertController(title: "結果", message: "\(toShuffle.randomElement()!)", preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alertController, animated: true, completion: nil)
    }
    @IBAction func SlideChange(_ sender: Any) {
        SlideValue.text = "\(Int(SlideObject.value))"
        SlideObject.value = Float(Int(SlideObject.value))
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.hideKeyboardWhenTappedAround()
        // 設定漸層顏色
        let color1 =  #colorLiteral(red: 0.8549019694, green: 0.250980407, blue: 0.4784313738, alpha: 1).cgColor
        let color2 =  #colorLiteral(red: 0.4745098054, green: 0.8392156959, blue: 0.9764705896, alpha: 1).cgColor
        let gradientLayer = CAGradientLayer()
        gradientLayer.frame = view.frame
        // color1 為第一個漸層色，color2 為第二個漸層色。
        gradientLayer.colors = [color1,color2]
        
        view.layer.insertSublayer(gradientLayer, at: 0)
        locationManager.requestAlwaysAuthorization()
        if (CLLocationManager.authorizationStatus() == CLAuthorizationStatus.authorizedWhenInUse ||
            CLLocationManager.authorizationStatus() == CLAuthorizationStatus.authorizedAlways){
            guard let currentLocation = locationManager.location else {
                return
            }
            Map.setCenter(CLLocationCoordinate2D(latitude: currentLocation.coordinate.latitude, longitude: currentLocation.coordinate.longitude), animated: true)
            Map.updateFocusIfNeeded()
            
        }
        
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
