//
//  ExamTool.swift
//  Hsuan Study
//
//  Created by student on 2019/12/21.
//  Copyright © 2019 tnfsh. All rights reserved.
//

import UIKit
import SafariServices
class ExamTool: UIViewController ,SFSafariViewControllerDelegate{
    let ans4 = ["A","B","C","D"],
        ans5 = ["A","B","C","D","E"]
    
    
    @IBOutlet weak var QuestionInput: UITextField!
    @IBAction func ClickAsk(_ sender: Any) {
        if QuestionInput.text != nil {
            var text = QuestionInput.text!
            text = text.replacingOccurrences(of: " ", with: "+")
            self.openURL(url: URL(string:
                "https://www.google.com/search?q=\(text)")!)
        }else{
            let alertController = UIAlertController(title: "Error", message: "The Input must NOT be blank!", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alertController, animated: true, completion: nil)
        }
    }
    func openURL(url:URL){
        let vc = SFSafariViewController(url: url)
        vc.delegate = self
        self.present(vc, animated: true, completion: nil)
    }
    @IBOutlet weak var HowMany: UITextField!
    @IBOutlet weak var TypeAns: UISegmentedControl!
    @IBAction func CalcRandomAns(_ sender: Any) {
        switch (TypeAns.selectedSegmentIndex) {
        case 0:
            var result = ""
            var num : Int
            if HowMany.text == nil {
                let alertController = UIAlertController(title: "Error", message: "The Input must NOT be blank!", preferredStyle: .alert)
                alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                self.present(alertController, animated: true, completion: nil)
            }else{
                num = Int(HowMany.text!)!
                for _ in 1...num{
                    result += "\(ans4.randomElement()!)\n"
                }
                let alertController = UIAlertController(title: "Done", message: result, preferredStyle: .alert)
                alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                self.present(alertController, animated: true, completion: nil)
            }
            break;
        case  1:
            var result = ""
            var num : Int
            if HowMany.text == nil {
                let alertController = UIAlertController(title: "Error", message: "The Input must NOT be blank!", preferredStyle: .alert)
                alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                self.present(alertController, animated: true, completion: nil)
            }else{
                num = Int(HowMany.text!)!
                for _ in 1...num{
                    result += "\(ans5.randomElement()!)\n"
                }
                let alertController = UIAlertController(title: "Done", message: result, preferredStyle: .alert)
                alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                self.present(alertController, animated: true, completion: nil)
            }
            break;
        default:
            break;
        }
        
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.hideKeyboardWhenTappedAround()
        // 設定漸層顏色
        let color1 =  #colorLiteral(red: 0.820551455, green: 1, blue: 0.7908681035, alpha: 1).cgColor
        let color2 =  #colorLiteral(red: 0.9568627477, green: 0.6588235497, blue: 0.5450980663, alpha: 1).cgColor
        let gradientLayer = CAGradientLayer()
        gradientLayer.frame = view.frame
        // color1 為第一個漸層色，color2 為第二個漸層色。
        gradientLayer.colors = [color1,color2]
        
        view.layer.insertSublayer(gradientLayer, at: 0)
        if let UserClass = UserDefaults.standard.object(forKey: "UserClass") as? String {
            
        }else{
            
        }
        
        // Do any additional setup after loading the view.
    }
    

}
