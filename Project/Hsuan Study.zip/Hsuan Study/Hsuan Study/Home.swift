//
//  Home.swift
//  Hsuan Study
//
//  Created by student on 2019/12/20.
//  Copyright © 2019 tnfsh. All rights reserved.
//

import UIKit
import SafariServices
class Home: UIViewController ,SFSafariViewControllerDelegate{
    func openURL(url:URL){
        let vc = SFSafariViewController(url: url)
        vc.delegate = self
        self.present(vc, animated: true, completion: nil)
    }
    @IBAction func GoSite(_ sender: Any) {
        self.openURL(url: URL(string: "https://study.hsuan.app")!)
    }
    override func viewDidLoad() {
        
        super.viewDidLoad()
        self.hideKeyboardWhenTappedAround()
        // 設定漸層顏色
        let color1 =  #colorLiteral(red: 0.631372549, green: 0.5490196078, blue: 0.8196078431, alpha: 1).cgColor
        let color2 =  #colorLiteral(red: 0.9843137255, green: 0.7607843137, blue: 0.9215686275, alpha: 1).cgColor
        let gradientLayer = CAGradientLayer()
        gradientLayer.frame = view.frame
        // color1 為第一個漸層色，color2 為第二個漸層色。
        gradientLayer.colors = [color1,color2]
        
        view.layer.insertSublayer(gradientLayer, at: 0)
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
