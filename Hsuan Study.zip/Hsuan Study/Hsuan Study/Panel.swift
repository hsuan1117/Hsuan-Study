//
//  Panel.swift
//  Hsuan Study
//
//  Created by student on 2019/12/27.
//  Copyright © 2019 tnfsh. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON
class Panel: UIViewController {

    @IBOutlet weak var input_Email: UITextField!
    @IBOutlet weak var input_Name: UITextField!
    @IBOutlet weak var label_Data: UILabel!
    @IBOutlet weak var GifLoading: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.hideKeyboardWhenTappedAround()
        // 設定漸層顏色
        let color1 =  #colorLiteral(red: 0.631372549, green: 0.5490196078, blue: 0.8196078431, alpha: 1).cgColor
        let color2 =  #colorLiteral(red: 0.9843137255, green: 0.7607843137, blue: 0.9215686275, alpha: 1).cgColor
        let gradientLayer = CAGradientLayer()
        gradientLayer.frame = view.frame
        // color1 為第一個漸層色，color2 為第二個漸層色。
        gradientLayer.colors = [color1,color2]
        
        view.layer.insertSublayer(gradientLayer, at: 0)
        GifLoading.loadGif(name: "loading")
        GifLoading.isHidden = true
        
        if let AccessToken = UserDefaults.standard.object(forKey: "AccessToken") as? String {
            let url = "https://script.google.com/macros/s/AKfycby-p_wJnMlqJ9cMp6z9s31PzCFGD8JB5kT3QBrdik-biF6VQpDI/exec?method=InfoGet&sessionID=\(AccessToken)"
            print(AccessToken)
            GifLoading.isHidden = false
            AF.request(url,method: .get).validate(contentType: ["application/json"]).responseJSON { response in
                self.GifLoading.isHidden = true
                print(response)
                if let json = try? JSON(data:response.data!) {
                    if json["status"].intValue == 1 {
                        self.label_Data.text = "註冊時間：\(json["data"][1].stringValue)"
                        self.input_Name.text = json["data"][2].stringValue
                        self.input_Email.text = json["data"][3].stringValue
                    }
                }
            }
        }
        // Do any additional setup after loading the view.
    }
    
    @IBAction func SaveProfile_Click(_ sender: Any) {
        if let AccessToken = UserDefaults.standard.object(forKey: "AccessToken") as? String {
            let url = "https://script.google.com/macros/s/AKfycby-p_wJnMlqJ9cMp6z9s31PzCFGD8JB5kT3QBrdik-biF6VQpDI/exec?method=InfoSet&sessionID=\(AccessToken)&name=\(input_Name.text!)&email=\(input_Email.text!)"
            print(AccessToken)
            GifLoading.isHidden = false
            AF.request(url,method: .get).validate(contentType: ["application/json"]).responseJSON { response in
                self.GifLoading.isHidden = true
                print(response)
                if let json = try? JSON(data:response.data!) {
                    if json["status"].intValue == 1 {
                        let alertController = UIAlertController(title: "Account Status", message: "儲存個人檔案成功", preferredStyle: .alert)
                        alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                        self.present(alertController, animated: true, completion: nil)
                        self.viewDidLoad()
                    }
                }
            }
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
