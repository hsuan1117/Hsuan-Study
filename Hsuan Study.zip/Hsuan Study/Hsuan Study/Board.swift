//
//  Board.swift
//  Hsuan Study
//
//  Created by student on 2020/1/3.
//  Copyright © 2020 hsuan. All rights reserved.
//

import UIKit
import SwiftyJSON
import Alamofire
class Board: UIViewController ,UITableViewDelegate,UITableViewDataSource{
    @IBOutlet weak var TableVC: UITableView!
    @IBOutlet weak var Progress: UIProgressView!
    var isSecond = false
    var AllBoards : Array<Array<String>> = [];
    var SelectedMessage : Array<String> = [];
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        print(AllBoards.count)
        return AllBoards.count
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1;
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = TableVC.dequeueReusableCell(withIdentifier: "comment")
        //print(AllBoards[indexPath.row][2])
        cell?.textLabel?.text = AllBoards[indexPath.row][2]
        if AllBoards[indexPath.row][4] == "" {
            cell?.detailTextLabel?.text = """
            作者: !!NOT Set
            發布時間: \(AllBoards[indexPath.row][1])
            """
        }else{
            cell?.detailTextLabel?.text = """
            作者: \(AllBoards[indexPath.row][4])
            發布時間: \(AllBoards[indexPath.row][1])
            """
        }
        
        
        return cell!
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.SelectedMessage.removeAll()
        self.SelectedMessage.append(AllBoards[indexPath.row][3])
        self.SelectedMessage.append(AllBoards[indexPath.row][2])
        
        let toOpen = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "vc_EditBoard")
        toOpen.modalPresentationStyle = .popover
        performSegue(withIdentifier: "toEditComment", sender: nil)
        //self.present(toOpen, animated: true, completion: nil)
    }
    
    @IBOutlet weak var inputText: UITextField!
    @IBAction func ClickSend(_ sender: Any) {
        if let AccessToken = UserDefaults.standard.object(forKey: "AccessToken") as? String {
            if inputText.text != nil {
                let url = "https://script.google.com/macros/s/AKfycby-p_wJnMlqJ9cMp6z9s31PzCFGD8JB5kT3QBrdik-biF6VQpDI/exec?method=BoardAdd&sessionID=\(AccessToken)&msg=\(inputText.text!)"
                let timer = Timer.scheduledTimer(withTimeInterval: 0.05, repeats: true, block: {_ in
                    if self.Progress.progress == 1.0 {
                        self.Progress.progress = 0
                    }else{
                        self.Progress.progress += 0.01
                    }
                })
                Progress.isHidden = false
                AF.request(url,method: .get).response{_ in
                    timer.invalidate()
                    //self.Progress.isHidden = true
                    self.AllBoards.removeAll()
                    
                    self.isSecond = true
                    self.viewDidLoad()
                }
            }
        }else{
            let alertController = UIAlertController(title: "Error", message: "Login First", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alertController, animated: true, completion: nil)
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.hideKeyboardWhenTappedAround()
        TableVC?.translatesAutoresizingMaskIntoConstraints = false
        TableVC.delegate = self
        TableVC.dataSource = self
        //Progress.transform = Progress.transform.scaledBy(x: -1, y: -10)
        if !isSecond {
            Progress.transform = Progress.transform.scaledBy(x: 1, y: 10)
        }
        
        
        Progress.isHidden = false
        let timer = Timer.scheduledTimer(withTimeInterval: 0.05, repeats: true, block: {_ in
            if self.Progress.progress == 1.0 {
                self.Progress.progress = 0
            }else{
                self.Progress.progress += 0.01
            }
        })
        let url = "https://script.google.com/macros/s/AKfycby-p_wJnMlqJ9cMp6z9s31PzCFGD8JB5kT3QBrdik-biF6VQpDI/exec?method=BoardGet"
        
        AF.request(url,method: .get).validate().responseJSON { response in
            print(response)
            if let json = try? JSON(data:response.data!) {
                timer.invalidate()
                self.Progress.isHidden = true
                for item in json["data"].arrayValue{
                    var __ : Array<String> = [] ;
                    for T in item.arrayValue {
                        let i = item.arrayValue.firstIndex(of: T)
                        if i == 1 {
                            let dateFormatter = DateFormatter()
                            dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"
                            dateFormatter.timeZone = TimeZone(abbreviation: "UTC")
                            __.append((dateFormatter.date(from: T.stringValue)?.description(with: Locale.current))!)
                        }else{
                            __.append(T.stringValue)
                        }
                    }
                    self.AllBoards.append(__)
                }
            }
            self.TableVC.reloadData()
        }
        
        
        // Do any additional setup after loading the view.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let vc = segue.destination as! EditBoard
        vc.data = SelectedMessage
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
