//
//  Settings.swift
//  Hsuan Study
//
//  Created by 張睿玹 on 2020/1/3.
//  Copyright © 2020 tnfsh. All rights reserved.
//

import UIKit
import SafariServices
class Settings: UIViewController,SFSafariViewControllerDelegate {
    @IBOutlet weak var input_Class: UITextField!
    @IBOutlet weak var input_Num: UITextField!
    @IBAction func ViewClassList(_ sender: Any) {
        saveChanges(alert: false)
        if input_Class.text != nil {
            self.openURL(url: URL(string:"http://w3.tnfsh.tn.edu.tw/deanofstudies/course/C101\(input_Class.text!).HTML")!)
        }
    }
    
    func openURL(url:URL){
        let vc = SFSafariViewController(url: url)
        vc.delegate = self
        self.present(vc, animated: true, completion: nil)
    }
    @IBAction func Save(_ sender: Any) {
        saveChanges(alert: true)
    }
    func saveChanges(alert:Bool){
        if input_Class.text != nil {
            UserDefaults.standard.set(input_Class.text!, forKey:"StudentClass")
        }else{
            UserDefaults.standard.set("", forKey:"StudentClass")
        }
        if input_Num.text != nil {
            UserDefaults.standard.set(input_Num.text!, forKey:"StudentNum")
        }else{
            UserDefaults.standard.set("", forKey:"StudentNum")
        }
        if alert {
            let alertController = UIAlertController(title: "Status", message: "儲存成功", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alertController, animated: true, completion: nil)
        }
        
        self.viewDidLoad()
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.hideKeyboardWhenTappedAround()
        // 設定漸層顏色
        let color1 =  #colorLiteral(red: 0.3543812335, green: 0.9260918498, blue: 1, alpha: 1).cgColor
        let color2 =  #colorLiteral(red: 0.7341687083, green: 1, blue: 0, alpha: 1).cgColor
        let gradientLayer = CAGradientLayer()
        gradientLayer.frame = view.frame
        // color1 為第一個漸層色，color2 為第二個漸層色。
        gradientLayer.colors = [color1,color2]
        
        view.layer.insertSublayer(gradientLayer, at: 0)
        if let Class = UserDefaults.standard.object(forKey: "StudentClass"){
            input_Class.text = Class as! String
        }
        if let Num = UserDefaults.standard.object(forKey: "StudentNum") {
            input_Num.text = Num as! String
        }
        
        // Do any additional setup after loading the view.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        saveChanges(alert: false)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
