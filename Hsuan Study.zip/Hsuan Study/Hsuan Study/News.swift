//
//  News.swift
//  Hsuan Study
//
//  Created by student on 2019/12/21.
//  Copyright © 2019 tnfsh. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON
import SafariServices
class News: UIViewController,UITableViewDelegate,UITableViewDataSource,SFSafariViewControllerDelegate {
    @IBOutlet weak var NewsTableView: UITableView!
    @IBOutlet weak var GifLoading: UIImageView!
    var ChinaTimesHeads : Array<String> = [];
    var ChinaTimesLinks : Array<String> = [];

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ChinaTimesHeads.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = NewsTableView.dequeueReusableCell(withIdentifier: "headline")
        cell?.textLabel?.text = ChinaTimesHeads[indexPath.row]
        cell?.detailTextLabel?.text = ChinaTimesLinks[indexPath.row]
        
        return cell!
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        self.openURL(url: URL(string:"https://www.chinatimes.com\(ChinaTimesLinks[indexPath.row])")!)
    }
    func openURL(url:URL){
        let vc = SFSafariViewController(url: url)
        vc.delegate = self
        self.present(vc, animated: true, completion: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.hideKeyboardWhenTappedAround()
        
        NewsTableView.dataSource = self
        NewsTableView.delegate = self
        
        //先載入
        GifLoading.isHidden = true
        GifLoading.loadGif(name: "loading")
        self.view.bringSubviewToFront(GifLoading)
        
        let url = "https://script.google.com/macros/s/AKfycby-p_wJnMlqJ9cMp6z9s31PzCFGD8JB5kT3QBrdik-biF6VQpDI/exec?method=News"
        GifLoading.isHidden = false
        
        AF.request(url,method: .get).validate().responseJSON { response in
            print(response)
            if let json = try? JSON(data:response.data!) {
                self.GifLoading.isHidden = true
                for item in json["ChinaTimes"].arrayValue{
                    self.ChinaTimesHeads.append(item["title"].stringValue)
                    self.ChinaTimesLinks.append(item["link"].stringValue)
                }
                for item in json["WantWant"].arrayValue{
                    self.ChinaTimesHeads.append(item["title"].stringValue)
                    self.ChinaTimesLinks.append(item["link"].stringValue)
                }
            }
            self.NewsTableView.reloadData()
        }
        // Do any additional setup after loading the view.
        
    }
}
