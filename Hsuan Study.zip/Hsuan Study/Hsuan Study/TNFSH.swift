//
//  TNFSH.swift
//  Hsuan Study
//
//  Created by 張睿玹 on 2020/1/5.
//  Copyright © 2020 hsuan. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON
import SafariServices
class TNFSH: UIViewController,SFSafariViewControllerDelegate {
    var start = "" , end = "";
    @IBOutlet weak var PickedEditMethod: UISegmentedControl!
    @IBOutlet weak var Progress: UIProgressView!
    @IBAction func EndEdit(_ sender: Any) {
        let DF = DateFormatter()
        DF.dateFormat = "yyyy-MM-dd"
        if PickedEditMethod.selectedSegmentIndex == 0 {
            self.start = DF.string(from: PickedDate.date)
        }else{
            self.end = DF.string(from: PickedDate.date)
        }
    }
    
    @IBAction func GetClassList(_ sender: Any) {
        if let StudentClass = UserDefaults.standard.value(forKey: "StudentClass"){
            self.openURL(url: URL(string:"http://w3.tnfsh.tn.edu.tw/deanofstudies/course/C101\(StudentClass).HTML")!)
        }
    }
    func openURL(url:URL){
        let vc = SFSafariViewController(url: url)
        vc.delegate = self
        self.present(vc, animated: true, completion: nil)
    }
    @IBAction func EndEdit2(_ sender: Any) {
        let DF = DateFormatter()
        DF.dateFormat = "yyyy-MM-dd"
        if PickedEditMethod.selectedSegmentIndex == 0 {
            self.start = DF.string(from: PickedDate.date)
        }else{
            self.end = DF.string(from: PickedDate.date)
        }
    }
    @IBOutlet weak var PickedDate: UIDatePicker!
    @IBAction func CheckRoll(_ sender: Any) {
        if let StudentNum = UserDefaults.standard.value(forKey: "StudentNum"),
            let StudentClass = UserDefaults.standard.value(forKey: "StudentClass"){
            let timer = Timer.scheduledTimer(withTimeInterval: 0.05, repeats: true, block: {_ in
                if self.Progress.progress == 1.0 {
                    self.Progress.progress = 0
                }else{
                    self.Progress.progress += 0.01
                }
            })
            Progress.isHidden = false
            let url="https://script.google.com/macros/s/AKfycby-p_wJnMlqJ9cMp6z9s31PzCFGD8JB5kT3QBrdik-biF6VQpDI/exec?method=RollCheck&start=\(start)&end=\(end)&class=\(StudentClass)&num=\(StudentNum)";
            print(url)
            var hasProblem : Dictionary<String,Array<String>> = [:];
            AF.request(url,method: .get).validate().responseJSON { response in
                timer.invalidate()
                self.Progress.isHidden = true
                if let json = try? JSON(data:response.data!) {
                    print("OK")
                    for i in json.arrayValue {
                        
                        var _index = 0;
                        var date = "";
                        var pro : Array<String> = [];
                        for item in i.arrayValue {
                            if _index == 0 {
                                date = item.stringValue
                            }else if item.stringValue != "正常" {
                                print("OK2")
                                pro.append("第\(_index)節\(item.stringValue)")
                            }
                            _index+=1
                        }
                        if pro.count != 0 {
                            hasProblem[date] = pro
                        }
                    }
                    var hasPass = true
                    var alertMessage = ""
                    for key in hasProblem {
                        if key.value.count != 0 {
                            alertMessage+="\n\(key.key):\n"
                            var __index = 0;
                            for classNum in key.value {
                                if __index==key.value.count-1 {
                                    alertMessage+="\(classNum)"
                                }else{
                                    alertMessage+="\(classNum),"
                                }
                                __index += 1;
                            }
                            hasPass = false
                        }
                    }
                    if hasPass {
                        let alertController = UIAlertController(title: "Great", message: "查詢區間無缺曠課紀錄", preferredStyle: .alert)
                        alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                        self.present(alertController, animated: true, completion: nil)
                    }else{
                        let alertController = UIAlertController(title: "QQ", message: alertMessage, preferredStyle: .alert)
                        alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                        self.present(alertController, animated: true, completion: nil)
                    }
                }
                
            }
            
            
        }else{
            let alertController = UIAlertController(title: "QQ", message: "Please Set your info", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: {
                (UIAlertAction) in
                let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "vc_Settings")
                self.present(vc, animated: true, completion: nil)
            }))
            self.present(alertController, animated: true, completion: nil)
            print("Fail")
        }
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.hideKeyboardWhenTappedAround()
        // 設定漸層顏色
        let color1 =  #colorLiteral(red: 0.5568627715, green: 0.3529411852, blue: 0.9686274529, alpha: 1).cgColor
        let color2 =  #colorLiteral(red: 0.4745098054, green: 0.8392156959, blue: 0.9764705896, alpha: 1).cgColor
        let gradientLayer = CAGradientLayer()
        gradientLayer.frame = view.frame
        // color1 為第一個漸層色，color2 為第二個漸層色。
        gradientLayer.colors = [color1,color2]
        
        view.layer.insertSublayer(gradientLayer, at: 0)
        Progress.transform = Progress.transform.scaledBy(x: 1, y: 10)
        
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
