//
//  EditBoard.swift
//  Hsuan Study
//
//  Created by 張睿玹 on 2020/1/4.
//  Copyright © 2020 hsuan. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON
class EditBoard: UIViewController {
    /**
     * @description 存放來自留言板的訊息資料以供編輯
     * @type {Array}
     */
    var data : Array<String> = []
    
    @IBOutlet weak var ViewComment: UITextView!
    @IBOutlet weak var EditButton: UIButton!
    @IBOutlet weak var Progress: UIProgressView!
    
    @IBAction func SaveChanges(_ sender: Any) {
        if let AccessToken = UserDefaults.standard.object(forKey: "AccessToken") as? String {
            if ViewComment.text != nil {
                let url = "https://script.google.com/macros/s/AKfycby-p_wJnMlqJ9cMp6z9s31PzCFGD8JB5kT3QBrdik-biF6VQpDI/exec?method=BoardEdit&sessionID=\(AccessToken)&msg=\(ViewComment.text!)&editID=\(data[0])"
                print(url)
                let timer = Timer.scheduledTimer(withTimeInterval: 0.05, repeats: true, block: {_ in
                    if self.Progress.progress == 1.0 {
                        self.Progress.progress = 0
                    }else{
                        self.Progress.progress += 0.01
                    }
                })
                Progress.isHidden = false
                AF.request(url,method: .get).responseJSON{response in
                    if let json = try? JSON(data:response.data!) {
                        if json["status"].intValue == 0 {
                            timer.invalidate()
                            self.Progress.isHidden = true
                            let alertController = UIAlertController(title: "Error", message: "Error, \(json["error"].stringValue)", preferredStyle: .alert)
                            alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: { (UIAlertAction) in
                            self.performSegue(withIdentifier: "finishEdit", sender: nil)
                            }))
                           
                            
                            self.present(alertController, animated: true, completion: nil)
                            
                        }else{
                            timer.invalidate()
                            self.Progress.isHidden = true
                            let alertController = UIAlertController(title: "Status", message: "Done", preferredStyle: .alert)
                            alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: {
                            (UIAlertAction) in
                                self.performSegue(withIdentifier: "finishEdit", sender: nil)
                            }))
                            self.present(alertController, animated: true, completion: nil)
                            
                        }
                    }
                    
                }
            }
        }else{
            let alertController = UIAlertController(title: "Error", message: "Login First", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alertController, animated: true, completion: nil)
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.hideKeyboardWhenTappedAround()
        Progress.isHidden = true
        
        /**
         * @description UI 美化程式碼
         */
        EditButton.layer.cornerRadius = 10
        ViewComment.layer.borderWidth = 1
        ViewComment.layer.borderColor = UIColor.black.cgColor
        Progress.transform = Progress.transform.scaledBy(x: 1, y: 10)
        
        ViewComment.text = data[1]
        
    }

}
